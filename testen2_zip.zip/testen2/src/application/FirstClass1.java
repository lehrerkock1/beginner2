package application;

public class FirstClass1 {

	public FirstClass1() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("kock");
	}

}
