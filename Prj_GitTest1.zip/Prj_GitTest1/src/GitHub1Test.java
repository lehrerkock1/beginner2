
public class GitHub1Test {

	public GitHub1Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Kock");
		//System.out.println("___");

	}

}
